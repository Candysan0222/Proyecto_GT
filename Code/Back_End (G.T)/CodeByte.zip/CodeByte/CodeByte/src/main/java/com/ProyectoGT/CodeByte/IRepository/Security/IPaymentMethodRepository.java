package com.ProyectoGT.CodeByte.IRepository.Security;

import com.ProyectoGT.CodeByte.Entity.Security.PaymentMethod;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface IPaymentMethodRepository extends IObjectTRepository<PaymentMethod>{

}
