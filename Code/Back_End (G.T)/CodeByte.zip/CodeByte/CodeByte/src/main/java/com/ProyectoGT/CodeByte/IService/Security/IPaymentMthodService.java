package com.ProyectoGT.CodeByte.IService.Security;

import com.ProyectoGT.CodeByte.Entity.Security.PaymentMethod;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface IPaymentMthodService extends IObjectTService<PaymentMethod>{

}
