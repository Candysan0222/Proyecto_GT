package com.ProyectoGT.CodeByte.Service.Operational;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Operational.BookingSeats;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class BookingSeatsService extends ObjectTService<BookingSeats>{

}
