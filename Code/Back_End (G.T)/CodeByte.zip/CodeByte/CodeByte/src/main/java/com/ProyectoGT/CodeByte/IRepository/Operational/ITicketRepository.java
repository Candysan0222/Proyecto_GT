package com.ProyectoGT.CodeByte.IRepository.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.Ticket;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface ITicketRepository extends IObjectTRepository<Ticket>{

}
