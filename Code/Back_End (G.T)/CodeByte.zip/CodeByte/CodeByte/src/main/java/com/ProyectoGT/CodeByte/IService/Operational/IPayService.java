package com.ProyectoGT.CodeByte.IService.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.Pay;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface IPayService extends IObjectTService<Pay>{

}
