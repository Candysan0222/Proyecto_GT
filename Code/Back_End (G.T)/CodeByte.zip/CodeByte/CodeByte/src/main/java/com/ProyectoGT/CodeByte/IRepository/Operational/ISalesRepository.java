package com.ProyectoGT.CodeByte.IRepository.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.Sales;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface ISalesRepository extends IObjectTRepository<Sales>{

}
