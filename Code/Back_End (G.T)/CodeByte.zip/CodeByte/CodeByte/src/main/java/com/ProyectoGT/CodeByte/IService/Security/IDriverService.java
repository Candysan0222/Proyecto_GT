package com.ProyectoGT.CodeByte.IService.Security;

import com.ProyectoGT.CodeByte.Entity.Security.Driver;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface IDriverService extends IObjectTService<Driver>{

}
