package com.ProyectoGT.CodeByte.IService.Security;

import com.ProyectoGT.CodeByte.Entity.Security.Person;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface IPersonService extends IObjectTService<Person>{

}
