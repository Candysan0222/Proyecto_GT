package com.ProyectoGT.CodeByte.IService.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.BusSeats;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface IBusSeatsService extends IObjectTService<BusSeats>{

}
