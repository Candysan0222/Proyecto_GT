package com.ProyectoGT.CodeByte.IRepository.Security;

import com.ProyectoGT.CodeByte.Entity.Security.Driver;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface IDriverRepository extends IObjectTRepository<Driver>{

}
