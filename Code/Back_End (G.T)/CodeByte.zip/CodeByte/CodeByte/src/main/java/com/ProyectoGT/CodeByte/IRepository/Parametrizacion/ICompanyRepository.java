package com.ProyectoGT.CodeByte.IRepository.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Company;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface ICompanyRepository extends IObjectTRepository<Company>{

}
