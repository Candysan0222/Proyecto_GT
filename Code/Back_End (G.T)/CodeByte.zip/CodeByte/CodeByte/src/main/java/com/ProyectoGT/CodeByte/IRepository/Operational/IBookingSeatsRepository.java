package com.ProyectoGT.CodeByte.IRepository.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.BookingSeats;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface IBookingSeatsRepository extends IObjectTRepository<BookingSeats>{

}
