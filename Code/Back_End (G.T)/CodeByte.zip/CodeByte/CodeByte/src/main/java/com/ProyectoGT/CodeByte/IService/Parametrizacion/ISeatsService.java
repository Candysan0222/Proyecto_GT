package com.ProyectoGT.CodeByte.IService.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Seats;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface ISeatsService extends IObjectTService<Seats>{

}
