package com.ProyectoGT.CodeByte.IService.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Bus;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface IBusService extends IObjectTService<Bus>{

}
