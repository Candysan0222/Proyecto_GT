package com.ProyectoGT.CodeByte.IRepository.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.BusSeats;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface IBusSeatsRepository extends IObjectTRepository<BusSeats>{

}
