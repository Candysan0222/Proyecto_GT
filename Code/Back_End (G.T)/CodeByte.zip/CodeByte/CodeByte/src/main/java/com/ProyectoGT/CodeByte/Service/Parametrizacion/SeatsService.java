package com.ProyectoGT.CodeByte.Service.Parametrizacion;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Seats;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class SeatsService extends ObjectTService<Seats>{

}
