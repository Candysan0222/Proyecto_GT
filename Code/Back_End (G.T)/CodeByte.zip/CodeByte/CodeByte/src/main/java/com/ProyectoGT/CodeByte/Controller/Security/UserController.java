package com.ProyectoGT.CodeByte.Controller.Security;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ProyectoGT.CodeByte.Controller.ObjectT.ObjectTController;
import com.ProyectoGT.CodeByte.DTO.IUserDTO;
import com.ProyectoGT.CodeByte.Entity.Security.User;
import com.ProyectoGT.CodeByte.Service.Security.UserService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping ("/Seguridad/Usuarios")
public class UserController extends ObjectTController<User>{
	
	private final UserService service;

    @Autowired
    public UserController(UserService service) {
        this.service = service;
    }

    @PostMapping("/GuardarUsuarioJwt")
    public User saveUsuarioJwt(@RequestBody User usuario) throws Exception{
        return service.saveUsuarioJwt(usuario);
    }


}
