package com.ProyectoGT.CodeByte.Service.Security;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Security.Driver;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class DriverService extends ObjectTService<Driver>{

}
