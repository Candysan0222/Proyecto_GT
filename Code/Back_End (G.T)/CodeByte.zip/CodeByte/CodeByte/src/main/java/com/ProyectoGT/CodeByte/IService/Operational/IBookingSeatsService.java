package com.ProyectoGT.CodeByte.IService.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.BookingSeats;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface IBookingSeatsService extends IObjectTService<BookingSeats>{

}
