package com.ProyectoGT.CodeByte.IService.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.Sales;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface ISalesService extends IObjectTService<Sales>{

}
