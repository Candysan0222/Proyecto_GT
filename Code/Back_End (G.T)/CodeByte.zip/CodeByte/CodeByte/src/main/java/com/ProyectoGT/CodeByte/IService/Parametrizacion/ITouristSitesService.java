package com.ProyectoGT.CodeByte.IService.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.TouristSite;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface ITouristSitesService extends IObjectTService<TouristSite>{

}
