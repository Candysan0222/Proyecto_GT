package com.ProyectoGT.CodeByte.Service.Operational;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Operational.Pay;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class PayService extends ObjectTService<Pay>{
	
}
