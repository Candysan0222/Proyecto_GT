package com.ProyectoGT.CodeByte.Service.Operational;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Operational.TravelPackages;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class TravelPackagesService extends ObjectTService<TravelPackages>{

}
