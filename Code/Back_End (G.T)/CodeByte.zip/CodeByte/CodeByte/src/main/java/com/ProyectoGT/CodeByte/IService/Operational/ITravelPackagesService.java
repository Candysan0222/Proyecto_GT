package com.ProyectoGT.CodeByte.IService.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.TravelPackages;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface ITravelPackagesService extends IObjectTService<TravelPackages>{

}
