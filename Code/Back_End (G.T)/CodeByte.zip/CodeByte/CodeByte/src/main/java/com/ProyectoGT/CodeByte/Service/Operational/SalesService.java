package com.ProyectoGT.CodeByte.Service.Operational;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Operational.Sales;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class SalesService extends ObjectTService<Sales>{

}
