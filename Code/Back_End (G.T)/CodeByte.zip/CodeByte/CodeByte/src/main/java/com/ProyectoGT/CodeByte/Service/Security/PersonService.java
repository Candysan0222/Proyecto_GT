package com.ProyectoGT.CodeByte.Service.Security;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Security.Person;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class PersonService extends ObjectTService<Person>{
	
}
