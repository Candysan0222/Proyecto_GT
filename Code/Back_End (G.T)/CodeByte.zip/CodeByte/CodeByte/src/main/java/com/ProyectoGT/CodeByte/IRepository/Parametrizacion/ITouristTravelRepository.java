package com.ProyectoGT.CodeByte.IRepository.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.TouristSite;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface ITouristTravelRepository extends IObjectTRepository<TouristSite>{
	
}
