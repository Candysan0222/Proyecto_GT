package com.ProyectoGT.CodeByte.IService.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Company;
import com.ProyectoGT.CodeByte.IService.ObjectT.IObjectTService;

public interface ICompanyService extends IObjectTService<Company>{

}
