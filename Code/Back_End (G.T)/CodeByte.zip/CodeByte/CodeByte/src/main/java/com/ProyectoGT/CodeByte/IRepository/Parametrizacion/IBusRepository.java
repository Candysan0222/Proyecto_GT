package com.ProyectoGT.CodeByte.IRepository.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Bus;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface IBusRepository extends IObjectTRepository<Bus>{

}
