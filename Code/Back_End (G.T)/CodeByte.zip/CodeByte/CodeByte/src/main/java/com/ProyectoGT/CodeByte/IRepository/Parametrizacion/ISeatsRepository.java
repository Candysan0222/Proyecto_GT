package com.ProyectoGT.CodeByte.IRepository.Parametrizacion;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Seats;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface ISeatsRepository extends IObjectTRepository<Seats>{

}
