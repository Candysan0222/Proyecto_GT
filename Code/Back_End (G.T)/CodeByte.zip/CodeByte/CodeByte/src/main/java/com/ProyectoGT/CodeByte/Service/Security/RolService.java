package com.ProyectoGT.CodeByte.Service.Security;


import org.springframework.stereotype.Service;
import com.ProyectoGT.CodeByte.Entity.Security.Role;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class RolService extends ObjectTService<Role>{


}
