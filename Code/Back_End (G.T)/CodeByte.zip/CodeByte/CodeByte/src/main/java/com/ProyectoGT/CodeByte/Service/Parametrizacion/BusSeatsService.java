package com.ProyectoGT.CodeByte.Service.Parametrizacion;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.BusSeats;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class BusSeatsService extends ObjectTService<BusSeats>{

}
