package com.ProyectoGT.CodeByte.IRepository.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.TravelPackages;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface ITravelPackagesRepository extends IObjectTRepository<TravelPackages>{

}
