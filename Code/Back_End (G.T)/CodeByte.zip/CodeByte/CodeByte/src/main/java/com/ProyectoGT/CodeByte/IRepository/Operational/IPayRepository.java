package com.ProyectoGT.CodeByte.IRepository.Operational;

import com.ProyectoGT.CodeByte.Entity.Operational.Pay;
import com.ProyectoGT.CodeByte.IRepository.ObjectT.IObjectTRepository;

public interface IPayRepository extends IObjectTRepository<Pay>{

}
