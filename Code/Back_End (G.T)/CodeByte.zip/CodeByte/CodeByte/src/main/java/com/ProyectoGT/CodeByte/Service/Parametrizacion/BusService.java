package com.ProyectoGT.CodeByte.Service.Parametrizacion;

import org.springframework.stereotype.Service;

import com.ProyectoGT.CodeByte.Entity.Parametrizacion.Bus;
import com.ProyectoGT.CodeByte.Service.ObjectT.ObjectTService;

@Service
public class BusService extends ObjectTService<Bus>{

}
