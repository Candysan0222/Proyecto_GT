package com.ProyectoGT.proyectoGT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoGtApplicationTests {

	@Test
	void contextLoads() {
	}

}
