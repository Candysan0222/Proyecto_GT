package com.ProyectoGT.proyectoGT.IService.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Pago;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IPagoService extends IObjetoTService<Pago>{

}
