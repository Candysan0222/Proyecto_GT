package com.ProyectoGT.proyectoGT.Service.Seguridad;

import org.springframework.stereotype.Service;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.Personas;
import com.ProyectoGT.proyectoGT.Service.ObjetoT.ObjetoTService;

@Service
public class PersonasService extends ObjetoTService<Personas>{

}
