package com.ProyectoGT.proyectoGT.Service.Parametrizacion;

import org.springframework.stereotype.Service;

import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.Buses;
import com.ProyectoGT.proyectoGT.Service.ObjetoT.ObjetoTService;

@Service
public class BusesService extends ObjetoTService<Buses>{

}
