package com.ProyectoGT.proyectoGT.IRepository.Parametrizacion;

import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.Buses;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;

public interface IBusesRepository extends IObjetoTRepository<Buses>{

}
