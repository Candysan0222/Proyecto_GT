package com.ProyectoGT.proyectoGT.IService.Parametrizacion;

import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.Amigos;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IAmigosService extends IObjetoTService<Amigos>{

}
