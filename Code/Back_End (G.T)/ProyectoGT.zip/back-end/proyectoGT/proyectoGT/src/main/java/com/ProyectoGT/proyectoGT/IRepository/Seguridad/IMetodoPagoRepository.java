package com.ProyectoGT.proyectoGT.IRepository.Seguridad;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.MetodoPago;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;


public interface IMetodoPagoRepository extends IObjetoTRepository<MetodoPago>{

}
