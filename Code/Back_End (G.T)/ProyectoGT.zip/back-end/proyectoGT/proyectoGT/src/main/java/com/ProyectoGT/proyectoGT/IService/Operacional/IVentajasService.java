package com.ProyectoGT.proyectoGT.IService.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Ventajas;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IVentajasService extends IObjetoTService<Ventajas>{

}
