package com.ProyectoGT.proyectoGT.IRepository.Parametrizacion;

import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.Amigos;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;

public interface IAmigosRepository extends IObjetoTRepository<Amigos>{

}
