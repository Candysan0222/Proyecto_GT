package com.ProyectoGT.proyectoGT.IService.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Reserva;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IReservaService extends IObjetoTService<Reserva>{

}
