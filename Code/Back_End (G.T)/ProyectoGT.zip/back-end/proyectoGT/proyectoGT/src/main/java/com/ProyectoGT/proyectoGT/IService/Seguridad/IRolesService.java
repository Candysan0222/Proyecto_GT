package com.ProyectoGT.proyectoGT.IService.Seguridad;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.Roles;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IRolesService extends IObjetoTService<Roles>{

}
