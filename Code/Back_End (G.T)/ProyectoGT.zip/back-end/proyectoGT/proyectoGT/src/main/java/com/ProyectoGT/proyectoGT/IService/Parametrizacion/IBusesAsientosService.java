package com.ProyectoGT.proyectoGT.IService.Parametrizacion;

import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.BusesAsientos;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IBusesAsientosService extends IObjetoTService<BusesAsientos>{

}
