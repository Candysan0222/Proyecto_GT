package com.ProyectoGT.proyectoGT.Entity.Seguridad;

import java.time.LocalDateTime;

import com.ProyectoGT.proyectoGT.Entity.CamposAuditoria;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="personas")
public class Personas extends CamposAuditoria{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false, length = 5)
	private Long id;
	
	@Column(name = "primer_nombre",nullable = false, length = 50)
	private String primerNombre;
	
	@Column(name = "segundo_nombre",nullable = false, length = 50)
	private String segundoNombre;
	
	@Column(name = "primer_apellido",nullable = false, length = 50)
	private String primerApellido;
	
	@Column(name = "segundo_apellido",nullable = false, length = 50)
	private String segundoApellido;
	
	@Column(name = "tipo_documento",nullable = false, length = 50)
	private String tipoDocumento;
	
	@Column(name = "num_documento",nullable = false, length = 50)
	private String numDocumento;
	
	@Column(name = "email",nullable = false, length = 100)
	private String email;
	
	@Column(name = "genero",nullable = false, length = 50)
	private boolean genero;	
	
	@Column(name = "fecha_nacimiento",nullable = false, length = 50)
	private LocalDateTime fechaNacimiento;

	public String getPrimerNombre() {
		return primerNombre;
	}

	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}

	public String getSegundoNombre() {
		return segundoNombre;
	}

	public void setSegundoNombre(String segundoNombre) {
		this.segundoNombre = segundoNombre;
	}

	public String getPrimerApellido() {
		return primerApellido;
	}

	public void setPrimerApellido(String primerApellido) {
		this.primerApellido = primerApellido;
	}

	public String getSegundoApellido() {
		return segundoApellido;
	}

	public void setSegundoApellido(String segundoApellido) {
		this.segundoApellido = segundoApellido;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isGenero() {
		return genero;
	}

	public void setGenero(boolean genero) {
		this.genero = genero;
	}

	public LocalDateTime getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(LocalDateTime fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}	
}
