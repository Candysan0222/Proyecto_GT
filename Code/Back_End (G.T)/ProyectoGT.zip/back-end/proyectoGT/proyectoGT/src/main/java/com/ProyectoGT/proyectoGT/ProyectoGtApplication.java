package com.ProyectoGT.proyectoGT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoGtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoGtApplication.class, args);
	}

}
