package com.ProyectoGT.proyectoGT.IService.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Ticket;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface ITicketService extends IObjetoTService<Ticket>{

}
