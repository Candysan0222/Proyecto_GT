package com.ProyectoGT.proyectoGT.Entity.Operacional;

import java.time.LocalDateTime;

import com.ProyectoGT.proyectoGT.Entity.CamposAuditoria;
import com.ProyectoGT.proyectoGT.Entity.Seguridad.Usuarios;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "reserva")
public class Reserva extends CamposAuditoria{
	
	@Column(name = "fecha",nullable = false)
	private LocalDateTime fecha;
	
	@Column(name = "descripcion",nullable = false, length = 150)
	private String descripcion;
	
	@ManyToOne
	@JoinColumn(name="usuario_id", nullable = false, unique=true)
	private Usuarios usuarioId;
	
	@ManyToOne
	@JoinColumn(name="paquete_id", nullable = false, unique=true)
	private Paquetes paqueteId;

	public LocalDateTime getFecha() {
		return fecha;
	}

	public void setFecha(LocalDateTime fecha) {
		this.fecha = fecha;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Usuarios getUsuarioId() {
		return usuarioId;
	}

	public void setUsuarioId(Usuarios usuarioId) {
		this.usuarioId = usuarioId;
	}

	public Paquetes getPaquetesId() {
		return paqueteId;
	}

	public void setPaquetesId(Paquetes paquetesId) {
		this.paqueteId = paquetesId;
	}
	
}
