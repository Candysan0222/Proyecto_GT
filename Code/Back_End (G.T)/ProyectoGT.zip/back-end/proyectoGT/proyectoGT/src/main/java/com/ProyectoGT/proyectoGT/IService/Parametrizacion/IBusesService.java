package com.ProyectoGT.proyectoGT.IService.Parametrizacion;

import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.Buses;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IBusesService extends IObjetoTService<Buses>{

}
