package com.ProyectoGT.proyectoGT.IRepository.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Paquetes;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;

public interface IPaquetesRepository extends IObjetoTRepository<Paquetes>{

}
