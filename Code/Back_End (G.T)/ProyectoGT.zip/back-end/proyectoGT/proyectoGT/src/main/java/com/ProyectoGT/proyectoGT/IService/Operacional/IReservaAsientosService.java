package com.ProyectoGT.proyectoGT.IService.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.ReservaAsientos;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IReservaAsientosService extends IObjetoTService<ReservaAsientos>{

}
