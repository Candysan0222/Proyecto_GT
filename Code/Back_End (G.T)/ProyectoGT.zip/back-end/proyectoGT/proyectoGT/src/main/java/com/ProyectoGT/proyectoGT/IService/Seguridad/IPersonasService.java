package com.ProyectoGT.proyectoGT.IService.Seguridad;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.Personas;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IPersonasService extends IObjetoTService<Personas>{

}
