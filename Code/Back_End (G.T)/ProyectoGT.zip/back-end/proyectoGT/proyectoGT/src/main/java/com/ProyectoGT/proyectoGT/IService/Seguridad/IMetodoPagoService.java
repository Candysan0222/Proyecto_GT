package com.ProyectoGT.proyectoGT.IService.Seguridad;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.MetodoPago;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IMetodoPagoService extends IObjetoTService<MetodoPago>{

}
