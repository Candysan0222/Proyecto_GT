package com.ProyectoGT.proyectoGT.IRepository.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Pago;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;

public interface IPagoRepository extends IObjetoTRepository<Pago>{

}
