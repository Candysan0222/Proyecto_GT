package com.ProyectoGT.proyectoGT.IRepository.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.ReservaAsientos;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;

public interface IReservaAsientosRepository extends IObjetoTRepository<ReservaAsientos>{

}
