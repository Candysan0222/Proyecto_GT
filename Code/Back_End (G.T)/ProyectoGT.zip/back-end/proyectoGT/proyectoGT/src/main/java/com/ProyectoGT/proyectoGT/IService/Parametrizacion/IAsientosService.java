package com.ProyectoGT.proyectoGT.IService.Parametrizacion;

import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.Asientos;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IAsientosService extends IObjetoTService<Asientos>{

}
