package com.ProyectoGT.proyectoGT.Service.Seguridad;

import org.springframework.stereotype.Service;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.Usuarios;
import com.ProyectoGT.proyectoGT.Service.ObjetoT.ObjetoTService;

@Service
public class UsuariosService extends ObjetoTService<Usuarios>{

}
