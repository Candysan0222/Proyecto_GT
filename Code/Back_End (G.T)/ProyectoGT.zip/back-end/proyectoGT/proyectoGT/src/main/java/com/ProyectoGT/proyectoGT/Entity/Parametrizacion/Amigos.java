package com.ProyectoGT.proyectoGT.Entity.Parametrizacion;

import com.ProyectoGT.proyectoGT.Entity.CamposAuditoria;
import com.ProyectoGT.proyectoGT.Entity.Seguridad.Usuarios;

import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="amigos")
public class Amigos extends CamposAuditoria{
	
	@ManyToOne
	@JoinColumn(name="usuario_id", nullable = false, unique=false)
	private Usuarios usuarioId;
	
	@ManyToOne
	@JoinColumn(name="amigo_id", nullable = false, unique=false)
	private Usuarios amigoId;

	public Usuarios getUsuarioId() {
		return usuarioId;
	}

	public void setUsuarioId(Usuarios usuarioId) {
		this.usuarioId = usuarioId;
	}

	public Usuarios getAmigoId() {
		return amigoId;
	}

	public void setAmigoId(Usuarios amigoId) {
		this.amigoId = amigoId;
	}

}
