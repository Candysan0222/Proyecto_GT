package com.ProyectoGT.proyectoGT.IService.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Paquetes;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IPaquetesService extends IObjetoTService<Paquetes>{

}
