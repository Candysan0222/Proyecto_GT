package com.ProyectoGT.proyectoGT.IService.Seguridad;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.Usuarios;
import com.ProyectoGT.proyectoGT.IService.ObjetoT.IObjetoTService;

public interface IUsuariosService extends IObjetoTService<Usuarios>{

}
