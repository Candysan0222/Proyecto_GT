package com.ProyectoGT.proyectoGT.Entity.Operacional;
import com.ProyectoGT.proyectoGT.Entity.CamposAuditoria;
import com.ProyectoGT.proyectoGT.Entity.Parametrizacion.Asientos;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "reserva_asientos")
public class ReservaAsientos extends CamposAuditoria{
	
	
	@ManyToOne
	@JoinColumn(name="reserva_id", nullable = false, unique=true)
	private Reserva reservaId;
	
	@ManyToOne
	@JoinColumn(name="asiento_id", nullable = false, unique=true)
	private Asientos asiento_id;

	public Reserva getReservaId() {
		return reservaId;
	}

	public void setReservaId(Reserva reservaId) {
		this.reservaId = reservaId;
	}

	public Asientos getAsiento_id() {
		return asiento_id;
	}

	public void setAsiento_id(Asientos asiento_id) {
		this.asiento_id = asiento_id;
	}
	
	
}
