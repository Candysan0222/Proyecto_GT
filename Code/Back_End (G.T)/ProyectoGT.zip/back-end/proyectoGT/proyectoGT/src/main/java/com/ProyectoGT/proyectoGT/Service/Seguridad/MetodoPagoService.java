package com.ProyectoGT.proyectoGT.Service.Seguridad;

import org.springframework.stereotype.Service;

import com.ProyectoGT.proyectoGT.Entity.Seguridad.MetodoPago;
import com.ProyectoGT.proyectoGT.Service.ObjetoT.ObjetoTService;

@Service
public class MetodoPagoService extends ObjetoTService<MetodoPago>{

}
