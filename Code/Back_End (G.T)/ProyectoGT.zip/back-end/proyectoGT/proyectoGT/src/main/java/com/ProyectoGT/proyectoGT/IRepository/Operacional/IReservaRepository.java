package com.ProyectoGT.proyectoGT.IRepository.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Reserva;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;

public interface IReservaRepository extends IObjetoTRepository<Reserva>{

}
