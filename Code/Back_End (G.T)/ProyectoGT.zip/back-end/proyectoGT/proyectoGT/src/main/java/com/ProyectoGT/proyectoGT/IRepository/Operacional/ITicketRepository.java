package com.ProyectoGT.proyectoGT.IRepository.Operacional;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Ticket;
import com.ProyectoGT.proyectoGT.IRepository.ObjetoT.IObjetoTRepository;

public interface ITicketRepository extends IObjetoTRepository<Ticket>{

}
