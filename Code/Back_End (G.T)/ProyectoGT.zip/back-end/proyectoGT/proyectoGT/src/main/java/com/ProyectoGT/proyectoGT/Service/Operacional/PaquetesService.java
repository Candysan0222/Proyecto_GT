package com.ProyectoGT.proyectoGT.Service.Operacional;

import org.springframework.stereotype.Service;

import com.ProyectoGT.proyectoGT.Entity.Operacional.Paquetes;
import com.ProyectoGT.proyectoGT.Service.ObjetoT.ObjetoTService;

@Service
public class PaquetesService extends ObjetoTService<Paquetes>{

}
